﻿namespace Zoo
{
    class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}
