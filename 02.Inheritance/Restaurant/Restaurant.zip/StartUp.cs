﻿namespace Restaurant
{
    public class StartUp
    {
        public StartUp()
        {
        }
    }
}
