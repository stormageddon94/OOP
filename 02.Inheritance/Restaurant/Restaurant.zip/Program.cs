﻿using System;

namespace Restaurant
{
    public class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}
