﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.Greedy_Times.Contracts
{
    public interface IJewel
    {
        public string Name { get; set; }

        public long Amount { get; set; }
    }
}
